"""Independent ODE fit for static nonspherical vacuum examples, geometrized units."""
import mpmath as mp
mp.mp.dps=60
u0=mp.mpf(4)
for delta in map(mp.mpf,['0.5','1','2']):
 def f(u):return ((u-1)/(u+1))**delta
 def qfun(u):return delta*f(u)*(u-delta)/(u*u-1)**2
 def ode(t,v):
  u,U,y,Y,w,W=v;q=qfun(u)
  return [U,-delta*f(u)/(u*u-1),Y,2*q*y,W,-q*w]
 for s in (mp.mpf(0),mp.mpf(1)):
  sol=mp.odefun(ode,0,[u0,-mp.sqrt(s*f(u0)),1,0,1,0],tol=mp.mpf('1e-49'),degree=32)
  exact=(delta*delta-1)/(15*(u0-delta)**2)+4*s*(delta*delta-1)*(delta*delta-3*delta*u0+3*u0*u0-1)/(45*delta*(u0-delta)**3)
  for h in map(mp.mpf,['0.08','0.04']):
   nodes=[mp.mpf(i)/14 for i in range(1,15)];vals=[]
   for t in nodes:
    v=sol(h*t);assert v[0]>max(1,delta) and v[2]>0 and v[4]>0;vals.append(mp.log(v[2])+2*mp.log(v[4]))
   cs=mp.lu_solve(mp.matrix([[t**j for j in range(4,18)] for t in nodes]),mp.matrix(vals));c4,c5,c6=[cs[j-4]/h**j for j in (4,5,6)];q=mp.sqrt(-2*c4);D=c6/q**3+mp.mpf(1)/15+125*c5*c5/(81*q**5)
   assert abs(D-exact)<mp.mpf('1e-8')
   print('delta',delta,'s',s,'h',h,'D',mp.nstr(D,16),'exact',mp.nstr(exact,16))
print('PASS: direct integration and independent volume-coefficient fitting.')
