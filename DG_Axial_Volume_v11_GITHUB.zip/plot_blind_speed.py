import numpy as np
import matplotlib.pyplot as plt
b=np.linspace(0,1,401)
fig,ax=plt.subplots(1,2,figsize=(8,3))
# C7/(epsilon sqrt(s)(1+s) q) = (3 A D2-beta² D3)/84
for A,D3,col,lab in [(1/8,-3/64,'#0072B2','Field I'),(1/4,-3/32,'#D55E00','Field II')]:
 ax[0].plot(b,(3*A*(-1/16)-b*b*D3)/84*1e4,c=col,label=lab)
ax[0].axhline(0,c='gray',lw=.7);ax[0].axvline(2**-.5,c='gray',ls='--',lw=.8)
ax[0].set(xlabel=r'$v/c$',ylabel=r'$10^4 C_7/[q\epsilon\sqrt{s}(1+s)]$',title='(a) Exact reduced coefficients');ax[0].legend(frameon=False,fontsize=8)
ax[1].plot([0,1],[7,7],c='#0072B2');ax[1].scatter([0,2**-.5],[8,8],c='#D55E00',zorder=3)
ax[1].scatter([0,2**-.5,1],[7,7,7],facecolor='white',edgecolor='#0072B2',zorder=3)
ax[1].set(xlim=(-.04,1.04),ylim=(6.75,8.25),yticks=[7,8],xlabel=r'$v/c$',ylabel='First distinguishing order',title='(b) Same pair, different preparations')
fig.tight_layout();fig.savefig('figure_blind_speed.png',dpi=220)
