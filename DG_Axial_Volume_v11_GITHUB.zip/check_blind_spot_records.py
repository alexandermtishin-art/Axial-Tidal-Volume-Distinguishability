"""Direct numerical Jacobi integration at the first exceptional Kerr ratio, two models and two speeds."""
import mpmath as mp
mp.mp.dps=60
P=lambda z:16*z*(1+z)**3-25*(1-6*z+z*z)**2
z=mp.findroot(P,(mp.mpf('.11'),mp.mpf('.12')))
F=z*(1+z)**2/(5*(1-3*z)**2)
lo=mp.sqrt(z);hi=(1+z)/2
# Same q=1, two distinct admissible compactnesses.
for frac in (mp.mpf(1)/3, mp.mpf(2)/3):
 x=lo+frac*(hi-lo);r0=mp.sqrt(x*(1-3*z)/(1+z)**3);m=x*r0;a=mp.sqrt(z)*r0
 for s in (mp.mpf(0),mp.mpf(1)):
  f=lambda r:1-2*m*r/(r*r+a*a)
  def ode(t,v):
   r,u,y,dy,w,dw=v;q=m*r*(r*r-3*a*a)/(r*r+a*a)**3
   return [u,-m*(r*r-a*a)/(r*r+a*a)**2,dy,2*q*y,dw,-q*w]
  sol=mp.odefun(ode,0,[r0,-mp.sqrt(s*f(r0)),1,0,1,0],tol=mp.mpf('1e-49'),degree=35)
  for h in (mp.mpf('.02'),mp.mpf('.01')):
   nodes=[mp.mpf(i)/14 for i in range(1,15)]
   vals=[]
   for t in nodes:
    v=sol(h*t); assert v[0]>m+mp.sqrt(m*m-a*a) and v[2]>0 and v[4]>0
    vals.append(mp.log(v[2])+2*mp.log(v[4]))
   coeff=mp.lu_solve(mp.matrix([[t**k for k in range(4,18)] for t in nodes]),mp.matrix(vals))
   c4,c5,c6=[coeff[k-4]/h**k for k in (4,5,6)]
   assert abs(c4+mp.mpf('.5'))<mp.mpf('1e-10')
   assert abs(c6-(F-mp.mpf(1)/15))<mp.mpf('1e-8')
   L=(1-6*z+z*z)**2*((1+z)/x-2)/(1-3*z)**3
   assert abs(c5*c5-mp.mpf(81)/100*s*L)<mp.mpf('1e-8')
   print('spin',mp.nstr(a/m,12),'s',s,'h',h,'C4',mp.nstr(c4,12),'C5',mp.nstr(c5,12),'C6',mp.nstr(c6,12))
print('PASS: two different spacetimes, two speeds, two windows; volume fits do not impose coefficient identities.')
