"""Lower-order radial alternatives and independent sixth-order consistency."""
import sympy as S
q, s, R = S.symbols('q s R', positive=True)
# q is the radial tidal scale. R=r/m. Use c=1.
J0,J1,J2,J3=S.symbols('J0:4',commutative=False)
J=[J0,J1,J2,J3]
X=[S.S.One,S.S.Zero]
for n in range(4):
    X.append(-sum(J[j]*X[n-j]/S.factorial(j) for j in range(n+1))/((n+1)*(n+2)))
assert S.expand(X[4]-X[2]**2/2)==-J0**2/12-J2/24
assert S.expand(X[5]-(X[2]*X[3]+X[3]*X[2])/2)==-J0*J1/30-J1*J0/60-J3/120
C4=-q**2/2
# (r'/r)^2=q*s*(R-2); sign of the fifth coefficient is the launch sign.
C5sq=S.Rational(81,100)*q**5*s*(R-2)
C6=-q**3/15-S.Rational(5,4)*q**3*s*(R-2)
assert S.simplify(2+100*C5sq/(81*s*q**5)-R)==0
assert S.simplify(2-4*(C6+q**3/15)/(5*q**3*s)-R)==0
assert S.simplify(C6+q**3/15+125*C5sq/(81*q**2))==0
print("Fourth/fifth trace coefficients and lower-order inversion identities: PASS.")
print("Independent sixth-order consistency residual: C6 + q^3/15 + 125*C5^2/(81*q^2) = 0.")
