"""Exact sixth-order Jacobi volume response in exterior Schwarzschild spacetime.

Run with Python 3 and SymPy: python verify_schwarzschild_sixth.py
The coordinates are (t, r, z=cos(theta), phi), m=GM/c**2, and c=1 in the
calculation. Printouts use geometrized proper time (length). Multiply each
order-six coefficient by c**6 when proper time is in seconds.

Convention: X'' = -J X, X(0)=I, X'(0)=0. Before the first caustic,
Theta_G = log det X = log(V/V0). For a cloud with initial covariance
Sigma0 and calibrated deformation Sigma = X Sigma0 X^T, the same readout
is +(1/2) log(det Sigma / det Sigma0). F6 is [tau**6] Pi Theta_G,
so a fitted sixth derivative must be divided by 6!. Pi is the signed
metric-moment extractor. A single directed volume need not have coefficient F6.
"""

from functools import lru_cache
from itertools import product

import sympy as sp


indices = range(4)
radius, mass = sp.symbols("r m", positive=True)
latitude = sp.Symbol("z", real=True)
lapse_squared = 1 - 2 * mass / radius
metric = (
    -lapse_squared,
    1 / lapse_squared,
    radius**2 / (1 - latitude**2),
    radius**2 * (1 - latitude**2),
)


def partial(expr, index):
    if index == 1:
        return sp.diff(expr, radius)
    if index == 2:
        return sp.diff(expr, latitude)
    return sp.S.Zero


@lru_cache(None)
def christoffel(a, b, c):
    """Levi-Civita symbol Gamma^a_bc for the diagonal metric."""
    first = partial(metric[a], b) if a == c else 0
    second = partial(metric[a], c) if a == b else 0
    third = partial(metric[b], a) if b == c else 0
    return sp.factor((first + second - third) / (2 * metric[a]))


def all_lower_riemann():
    curvature = {}
    for a, b, c, d in product(indices, repeat=4):
        derivative = partial(christoffel(a, d, b), c) - partial(christoffel(a, c, b), d)
        connection = sum(
            christoffel(a, c, j) * christoffel(j, d, b)
            - christoffel(a, d, j) * christoffel(j, c, b)
            for j in indices
        )
        component = sp.factor(metric[a] * (derivative + connection))
        if component:
            curvature[a, b, c, d] = component
    for b, d in product(indices, repeat=2):
        ricci = sum(curvature.get((a, b, a, d), 0) / metric[a] for a in indices)
        assert sp.factor(ricci) == 0
    return curvature


def covariant_derivative(tensor):
    """All slots are lower. The new derivative index is prepended."""
    result = {}
    rank = len(next(iter(tensor)))
    for k in indices:
        for slots in product(indices, repeat=rank):
            value = partial(tensor.get(slots, 0), k)
            for n, slot in enumerate(slots):
                for j in indices:
                    gamma = christoffel(j, k, slot)
                    if gamma:
                        replaced = slots[:n] + (j,) + slots[n + 1:]
                        value -= gamma * tensor.get(replaced, 0)
            if value:
                value = sp.factor(value)
                if value:
                    result[(k,) + slots] = value
    return result


# Spherical symmetry permits evaluation at z=0 after all covariant derivatives.
inverse = tuple(sp.factor((1/g).subs(latitude, 0)) for g in metric)


def tidal_polynomial(curvature_jet):
    """Produce a matrix coefficient for each monomial in the components of u.

    The tidal endomorphism acts on spacetime and annihilates u. Its nonzero
    transverse block and all trace products coincide with the screen ones.
    """
    polynomial = {}
    for slots, value in curvature_jet.items():
        a, i, b, j = slots[-4:]
        value = sp.factor(inverse[a] * value.subs(latitude, 0))
        if value:
            monomial = tuple(sorted(slots[:-4] + (i, j)))
            if monomial not in polynomial:
                polynomial[monomial] = sp.zeros(4)
            polynomial[monomial][a, b] += value
    return polynomial


@lru_cache(None)
def sixth_moment(slots):
    """Pi(u^a ... u^f) using the diagonal inverse metric and u.u=-1."""
    assert len(slots) == 6
    result = -sp.Rational(1, 4 * 6 * 8)
    for i in indices:
        n = slots.count(i)
        if n % 2:
            return sp.S.Zero
        result *= sp.factorial2(n - 1) * inverse[i]**(n // 2)
    return result


def projected_trace(*factors):
    """Multiply the directional matrices, trace, and sum exact signed moments."""
    contributions = []
    for terms in product(*(factor.items() for factor in factors)):
        slots = tuple(sorted(i for monomial, _ in terms for i in monomial))
        weight = sixth_moment(slots)
        if not weight:
            continue
        matrix = terms[0][1]
        for _, next_matrix in terms[1:]:
            matrix = matrix * next_matrix
        contributions.append(weight * matrix.trace())
    return sp.factor(sum(contributions))


def directional_sixth_coefficients():
    """Expand tr log X from X''=-J X without commuting the tidal matrices."""
    js = sp.symbols("J0:5", commutative=False)
    series = [sp.S.One, sp.S.Zero]
    for n in range(5):
        product_sum = sum(js[k]*series[n-k]/sp.factorial(k) for k in range(n+1))
        series.append(-product_sum / ((n+1)*(n+2)))
    # Y = X-I begins at order two, so Y-Y^2/2+Y^3/3 is sufficient.
    sixth = series[6] - sum(series[j]*series[6-j] for j in (2,3,4))/2 + series[2]**3/3
    cyclic = {}
    for term in sp.Add.make_args(sp.expand(sixth)):
        coeff, word = term.as_coeff_Mul()
        factors = []
        for factor in sp.Mul.make_args(word):
            atom, power = factor.as_base_exp()
            factors.extend([js.index(atom)] * int(power))
        rotations = [factors[j:] + factors[:j] for j in range(len(factors))]
        canonical = tuple(min(rotations))
        cyclic[canonical] = cyclic.get(canonical, 0) + coeff
    assert cyclic == {
        (0,0,0): -sp.Rational(1,45), (0,2): -sp.Rational(1,90),
        (1,1): -sp.Rational(1,120), (4,): -sp.Rational(1,720),
    }
    return cyclic


def main():
    curvature = all_lower_riemann()
    first = covariant_derivative(curvature)
    second = covariant_derivative(first)
    jets = [tidal_polynomial(t) for t in (curvature, first, second)]
    cyclic = directional_sixth_coefficients()

    # Ricci=0 gives tr J4=0 on every geodesic. Use the other three raw terms.
    frozen = cyclic[(0,0,0)] * projected_trace(jets[0], jets[0], jets[0])
    mixed = projected_trace(jets[0], jets[2])
    square = projected_trace(jets[1], jets[1])
    full = sp.factor(frozen + cyclic[(0,2)]*mixed + cyclic[(1,1)]*square)

    # Independent invariant calculation in the diagonal bivector basis.
    assert all({a,b} == {c,d} for a,b,c,d in curvature)
    eigenvalues = [
        inverse[a] * inverse[b] * curvature[a,b,a,b].subs(latitude,0)
        for a in indices for b in indices if a < b
    ]
    i2 = sp.factor(4 * sum(v**2 for v in eigenvalues))
    i3 = sp.factor(8 * sum(v**3 for v in eigenvalues))
    box_i2 = sp.factor(sp.diff(radius**2*lapse_squared*sp.diff(i2, radius), radius) / radius**2)
    assert i2 == 48*mass**2/radius**6 and i3 == 96*mass**3/radius**9
    assert sp.factor(frozen-i3/2880) == 0
    assert sp.factor(full - i3/4608 - box_i2/15360) == 0
    assert sp.factor(full - mass**2*(45*radius-98*mass)/(480*radius**9)) == 0
    ratio = sp.factor(full/frozen)
    assert sp.factor(ratio.subs(radius,98*mass/45)) == 0
    assert sp.factor(ratio.subs(radius,12*mass/5)) == sp.Rational(5,8)
    print("I2 =", i2, "   I3 =", i3)
    print("Box I2 =", box_i2)
    print("Frozen F6 =", sp.factor(frozen))
    print("Full F6 =", full)
    print("Full / frozen =", ratio)
    print("Exterior zero: r/(2m)=49/45.   Full/frozen=5/8 at r/(2m)=6/5.")


if __name__ == "__main__":
    main()
