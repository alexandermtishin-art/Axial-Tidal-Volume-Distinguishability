"""Exact checks for a seven-velocity, degree-six scalar rule (c = 1).

Unit timelike vector in an orthonormal static tetrad: T = u0^2, B = ur^2,
C = utheta^2 + uphi^2. A static and locally spherically symmetric response
of even degree six belongs to the ten-dimensional homogeneous cubic space
spanned by T^a B^b C^d below. The check does not use the Schwarzschild
field equations. The optional radial-only identity at the end does.
"""
from math import comb
from sympy import Rational as Q, binomial, factorial2, simplify, sqrt, symbols

shells = (0, Q(1, 4), Q(3, 4), 1)
shell_weights = (Q(46, 3), -Q(47, 2), Q(97, 6), -7)
angles = (Q(3, 7) - 2 * sqrt(30) / 35, Q(3, 7) + 2 * sqrt(30) / 35)
angle_weights = (Q(1, 2) + sqrt(30) / 36, Q(1, 2) - sqrt(30) / 36)

def normalized_lorentz_moment(a, b, d):
    # Formal sixth moment -1/192 times the symmetric metric contractions.
    # Expand (uy^2 + uz^2)^d. Sign of time pairings is (-1)^a.
    transverse = sum(comb(d, j) * factorial2(2*j - 1) * factorial2(2*(d-j) - 1)
                     for j in range(d+1))
    return (-1)**(a+1) * factorial2(2*a-1) * factorial2(2*b-1) * transverse / 192

def signed_sample(a, b, d):
    total = 0
    for s, weight in zip(shells, shell_weights):
        mean = sum(w*(1+s)**a*(s*U)**b*(s*(1-U))**d for U,w in zip(angles, angle_weights))
        total += weight * mean
    return simplify(total)

assert sum(shell_weights) == 1
assert sum(abs(w) for w in shell_weights) == 62
for a in range(4):
    for b in range(4-a):
        d = 3-a-b
        analytic = normalized_lorentz_moment(a,b,d)
        sampled = signed_sample(a,b,d)
        assert analytic == sampled, (a,b,d,analytic,sampled)
        print(f'{a},{b},{d}: {analytic}')
print('All ten independent invariant monomials agree. Nodes: 7. Error norm: 62.')

m,r=symbols('m r',positive=True)
k=m/r**3
intercept = -k**3/15
slope = -Q(5, 4)*k**2*(1-2*m/r)/r**2
projected = (96*k**3)/4608 + (288*m**2/r**9*(5*r-12*m))/15360
assert simplify(projected-intercept/4+3*slope/40) == 0
print('Schwarzschild radial-only, model-dependent interpolation formula verified algebraically.')
