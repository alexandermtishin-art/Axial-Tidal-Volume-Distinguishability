"""Check the radial inverse formulas and scalar identity exactly, c=G=1."""
import sympy as sp
r,m,s=sp.symbols('r m s', positive=True)
f=1-2*m/r
q=m/r**3
rp2=f*s
qpp=12*q*rp2/r**2+3*q**2
qp2=9*q**2*rp2/r**2
C=sp.expand(2*q**3/15-q*qpp/15-qp2/20)
A=sp.factor(C.subs(s,0))
B=sp.factor(sp.diff(C,s))
F=sp.factor(A/4-3*B/40)
assert sp.simplify(F-m**2*(45*r-98*m)/(480*r**9))==0
assert sp.simplify(2+4*B/(75*A)-r/m)==0
I3=96*m**3/r**9; N=720*m**2*(r-2*m)/r**9
assert sp.simplify(I3+1440*A)==0
assert sp.simplify(N+576*B)==0
assert sp.simplify(F.subs(r,98*m/45))==0
assert sp.Rational(13,40)+sp.Rational(3,40)==sp.Rational(2,5)
assert (2**8+16)/sp.S(48)==sp.Rational(17,3)
print('A =',A)
print('B =',B)
print('F6 =',F)
print('Compactness and curvature-invariant mappings verified. Measurement norm = 2/5; window remainder multiplier = 17/3.')
