"""Integrate independent volume histories and fit C4..C7 without using analytic identities."""
import mpmath as mp
mp.mp.dps=60
Q=mp.mpf(1)/128
for name,r0,m,a in [('ZV',mp.mpf(3),mp.mpf(2),mp.mpf(0)),('Kerr',mp.mpf(4),4*(mp.sqrt(2)-1),4*(mp.sqrt(2)-1))]:
 if name=='ZV':
  f=lambda r:((r-1)/(r+1))**2; q=lambda r:2*f(r)*(r-2)/(r*r-1)**2
  accel=lambda r:-2*f(r)/(r*r-1)
 else:
  f=lambda r:1-2*m*r/(r*r+a*a);q=lambda r:m*r*(r*r-3*a*a)/(r*r+a*a)**3
  accel=lambda r:-m*(r*r-a*a)/(r*r+a*a)**2
 for s in (mp.mpf(0),mp.mpf(1),mp.mpf(2)):
  def ode(t,v):
   r,u,y,Y,w,W=v;A=q(r);return [u,accel(r),Y,2*A*y,W,-A*w]
  sol=mp.odefun(ode,0,[r0,-mp.sqrt(s*f(r0)),1,0,1,0],tol=mp.mpf('1e-50'),degree=35)
  for h in (mp.mpf('.04'),mp.mpf('.02')):
   nodes=[mp.mpf(k)/16 for k in range(1,17)]
   y=[]
   for t in nodes:
    v=sol(h*t);assert v[0]>(1 if name=='ZV' else m) and v[2]>0 and v[4]>0
    y.append(mp.log(v[2])+2*mp.log(v[4]))
   c=mp.lu_solve(mp.matrix([[t**k for k in range(4,20)] for t in nodes]),mp.matrix(y));c4,c5,c6,c7=[c[k-4]/h**k for k in range(4,8)];v7=c7/Q**mp.mpf('3.5');expected=2*mp.sqrt(2*s)*(10*s+3)/7
   if name=='Kerr':expected*=mp.sqrt(mp.mpf('.5')+mp.sqrt(2)/4)
   assert abs(c4/Q**2+mp.mpf('.5'))<mp.mpf('1e-15') and abs(c5/Q**mp.mpf('2.5'))<mp.mpf('1e-15') and abs(c6/Q**3-(mp.mpf(2)/15+8*s/5))<mp.mpf('1e-13') and abs(v7-expected)<mp.mpf('1e-11')
   c8=c[4]/h**8/Q**4
   if s==0:
    target=mp.mpf(19)/140 if name=='ZV' else (1+9*mp.sqrt(2))/140
    assert abs(c8-target)<mp.mpf('1e-11')
   print(name,'s=',s,'h=',h,'C4/Q²=',mp.nstr(c4/Q**2,13),'C5/Q^2.5=',mp.nstr(c5/Q**mp.mpf('2.5'),5),'C6/Q³=',mp.nstr(c6/Q**3,15),'C7/Q^3.5=',mp.nstr(v7,15),'C8/Q^4 (rest)' if s==0 else '',mp.nstr(c8,15) if s==0 else '')
print('PASS: independent direct integration; two windows, three speeds and both models.')
