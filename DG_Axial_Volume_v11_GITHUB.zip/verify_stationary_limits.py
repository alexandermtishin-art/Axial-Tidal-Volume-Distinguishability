"""Exact checks of stationary-gradient volume response; units c=1."""
import sympy as S
z,h=S.symbols('z h',real=True)
R=S.Rational
# Two candidate exterior Weyl metrics: axis U(z)=sum a_n/z^n.
# Fixed positive monopole mass (a1=-1). Remaining moments match an axial lapse jet.
def example(f5,fp=R(1,4)):
    fjet=1+fp*h-h**2/4+h**4/96+f5*h**5/120
    Ujet=S.series(S.log(fjet)/2,h,0,6).removeO()
    coeff=S.symbols('a2:8')
    U=-1/z+sum(a/z**n for n,a in enumerate(coeff,2))
    sol=S.solve([S.diff(U,z,k).subs(z,1)-S.diff(Ujet,h,k).subs(h,0) for k in range(6)],coeff)
    U=U.subs(sol);f=S.exp(2*U)
    jet=[S.diff(f,z,k).subs(z,1).simplify() for k in range(6)]
    assert jet==[1,fp,-R(1,2),0,R(1,4),f5]
    F,Fp,_,_,F4,F5=jet
    q=R(1,8);A=Fp/(2*S.sqrt(F));D2=-F*F4/4
    D3=-F**R(3,2)*F5/4+3*A*D2
    assert A==fp/2 and D2==-R(1,16)
    print('axis potential:', S.factor(U))
    print('q,A,q_ll,q_lll:',q,A,D2,D3)
    print('beta_star_squared:', S.simplify(3*A*D2/D3))
    return S.simplify(3*A*D2/D3), A, S.diff(f,z,6).subs(z,1).simplify()
ex1=example(R(3,32));ex2=example(R(3,16),R(1,2));ex3=example(0)
assert ex1[0]==ex2[0]==R(1,2) and ex3[0]==1
# At s=1 (beta^2=1/2) both C7 vanish. Different A and q4 -> separation at C8.
def qt4(ex):
    _,A,f6=ex;fp=2*A;fpp=-R(1,2);qr2=-R(1,16)
    qr3=R(3,2)*fp*qr2
    return -f6/4-3*fp*qr3+3*qr2*fp**2/4-2*qr2*fpp
diff=S.simplify(-(qt4(ex2)-qt4(ex1))/4480)
assert diff!=0
print("C8 difference at blind moving speed (second minus first):",diff)
print("C8 difference at rest (second minus first):", S.simplify(-R(1,8)*3*(ex2[1]**2-ex1[1]**2)*(-R(1,16))/560))
# Stationary positive-tide ZV upper root, set t=u-delta>0
d,t=S.symbols('d t',positive=True)
u=d+t
n=-d**3+6*d**2*u-9*d*u**2-2*d+3*u**3+3*u
p=2*d**4-20*d**3*u+60*d**2*u**2+10*d**2-60*d*u**3-40*d*u+15*u**4+30*u**2+3
assert S.factor(S.rem(S.expand(n),d*d-1-3*t*t,d))==-3*t**2*(d+2*t)
assert S.factor(S.rem(S.expand(p),d*d-1-3*t*t,d))==-6*t**2*(10*d*t+17*t*t+3)
# Internal linear spring response about the initial lengths
q,q1,q2,q3,q4,b=S.symbols('q q1 q2 q3 q4 b')
Q=[q,q1,q2/2,q3/6,q4/24,0,0]
def loglength(h):
    y=[S.Integer(1),S.Integer(0)]
    for n in range(7):
        y.append(S.expand((h*sum(Q[k]*y[n-k] for k in range(n+1))-b*(y[n]-int(n==0)))/((n+1)*(n+2))))
    l=[S.Integer(0)]
    for n in range(1,9):
        l.append(S.expand(y[n]-sum(k*l[k]*y[n-k] for k in range(1,n))/n))
    return l
l,w=loglength(2),loglength(-1)
C=[S.factor(x+2*y) for x,y in zip(l,w)]
for n in range(4,9):print('C'+str(n), C[n])
assert C[4]==-q*q/2
assert S.factor(C[6].subs(q1,0)-(13*b*q*q/120+2*q**3/15-q*q2/15))==0
assert C[7].subs(q1,0)==-q*q3/84
assert S.factor(C[8].subs({q1:0,q2:0,q3:0})+b*b*q*q/112+99*b*q**3/2240+17*q**4/140+q*q4/560)==0
print('PASS')
# Frozen constant q: explicit spring-focusing threshold.
t,Q,B=S.symbols('t Q B',positive=True)
w=(B+Q*S.cos(S.sqrt(B+Q)*t))/(B+Q)
assert S.simplify(S.diff(w,t,2)+Q*w+B*(w-1))==0
assert w.subs(t,0)==1 and S.diff(w,t).subs(t,0)==0
assert S.simplify(w.subs(t,S.pi/S.sqrt(B+Q))-(B-Q)/(B+Q))==0
y=1+Q*t*t
assert S.simplify(S.diff(y,t,2)-2*Q*y+2*Q*(y-1))==0
print('PASS: transverse focusing iff b<=q for constant q; longitudinal marginality b=2q.')
# Direct formal central-geodesic series and both length series, independent
# of the fourth-derivative identity used above.
def direct_record(ex,f5,s):
    _,A,f6=ex;T=S.Symbol('T');h=S.Symbol('h')
    f=1+2*A*h-h*h/4+h**4/96+f5*h**5/120+f6*h**6/720
    xx=S.sqrt(s)*T
    for n in range(3):
        coeff=S.expand((-S.diff(f,h)/2).subs(h,xx)).coeff(T,n)
        xx+=coeff*T**(n+2)/((n+1)*(n+2))
    qt=S.Poly(S.series((-S.diff(f,h,2)/4).subs(h,xx),T,0,5).removeO(),T)
    def L(k):
        a=[S.Integer(1),S.Integer(0)]
        for n in range(7):
            a.append(S.expand(k*sum(qt.nth(j)*a[n-j] for j in range(n+1))/((n+1)*(n+2))))
        l=[S.Integer(0)]
        for n in range(1,9):
            l.append(S.expand(a[n]-sum(j*l[j]*a[n-j] for j in range(1,n))/n))
        return l
    y,w=L(2),L(-1)
    return [S.simplify(y[n]+2*w[n]) for n in range(9)]
for s in [0,1,2]:
    r1=direct_record(ex1,R(3,32),s);r2=direct_record(ex2,R(3,16),s)
    assert r1[:7]==r2[:7]
    if s in [0,1]:
        assert r1[7]==r2[7]==0
        assert r2[8]-r1[8]==(R(9,4587520) if s==0 else diff)
    else:assert r1[7]!=r2[7]
    print('Direct series s=',s,'difference C7,C8:',r2[7]-r1[7],r2[8]-r1[8])
print('PASS: direct central-geodesic and length series independently check blind-speed order.')
# Arbitrary prescribed blind speed: the 7x7 axis-multipole jet map is invertible.
M=S.Matrix([[S.diff(z**(-n),z,k).subs(z,1) for n in range(2,9)] for k in range(7)])
assert M.det()!=0
print('Axis multipole jet determinant:',M.det())
B,A,L=S.symbols('B A L', nonzero=True)
D2=-R(1,16);f5=-12*A*D2*(1/B-1)
D3=-f5/4+3*A*D2
assert S.simplify(B*D3-3*A*D2)==0
# With f=1, the free sixth lapse derivative contributes -s² f6/4 to q^(4).
# C8 contains -q q^(4)/560, thus coefficient of f6 is nonzero for s>0.
assert S.simplify(R(1,8)*(B/(1-B))**2/2240-B**2/(17920*(1-B)**2))==0
print('PASS: any prescribed 0<beta²<1; free f6 permits nonzero C8 difference.')
