"""Build Figure 1 from the exact normalized sixth-order scalar."""
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
x = np.linspace(1,1.30,400)
fig, ax = plt.subplots(figsize=(6.1,2.65), layout="constrained")
ax.plot(x,(90*x-98)/16,label="Full Jacobi response",color="#245b6b",lw=2)
ax.axhline(1,ls="--",color="0.45",label="Frozen tidal field")
ax.axhline(0,color=".75",lw=.7)
ax.plot([49/45],[0],"o",color="#245b6b",ms=4)
ax.annotate("49/45",(49/45,0),xytext=(8,-15),textcoords="offset points",fontsize=9)
ax.plot([1.2],[.625],marker="s",mfc="white",mec="#245b6b")
ax.annotate("5/8",(1.2,.625),xytext=(7,-14),textcoords="offset points",fontsize=9)
ax.plot([1],[-.5],marker="o",mfc="white",mec="#245b6b")
ax.set(xlabel=r"Areal radius $r/r_s$",ylabel=r"$F_6/F_{6,\mathrm{frozen}}$",xlim=(.995,1.3))
ax.legend(loc="upper left",frameon=False,fontsize=8,ncols=2)
fig.savefig(Path(__file__).resolve().parent/"figure1.png",dpi=240)
