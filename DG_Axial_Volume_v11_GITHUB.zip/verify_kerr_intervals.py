"""Exact coefficient error boxes and spin dependence of the axial residual."""
import sympy as S
r=S.Rational(3); a=S.Rational(1,2); m=S.Integer(1); s=S.Integer(1)
x=S.symbols('x',positive=True)
f=lambda r,a:1-2*r/(r*r+a*a)
qfun=lambda r,a:r*(r*r-3*a*a)/(r*r+a*a)**3
q=qfun(r,a); qp=S.diff(qfun(x,a),x).subs(x,r)*(-S.sqrt(s*f(r,a)))
c4=-q*q/2;c5=-3*q*qp/10
D=a*a*r*(r*r-3*a*a)/(5*(r*r+a*a)**7)+4*a*a*s*(r*r-2*r+a*a)/(5*(r*r+a*a)**6)
c6s=-q**3/15-125*c5*c5/(81*q*q);c6k=c6s+D
err=S.Rational(1,1000)
ql=q*S.sqrt(1-err);qu=q*S.sqrt(1+err);pl=abs(c5)*(1-err);pu=abs(c5)*(1+err)
def box(c6):
 l=c6*(1+err);u=c6*(1-err)
 return l/ql**3+S.Rational(1,15)+125*pl*pl/(81*qu**5),u/qu**3+S.Rational(1,15)+125*pu*pu/(81*ql**5)
for name,c6,bounds in [('Schwarzschild',c6s,(-8721,8738)),('Kerr',c6k,(32298,49552))]:
 lo,hi=box(c6);assert bool(lo>S.Rational(bounds[0],10**6));assert bool(hi<S.Rational(bounds[1],10**6));print(name, S.N(lo,18),S.N(hi,18))
assert bool(box(c6s)[1]<box(c6k)[0]);print('PASS: disjoint exact coefficient boxes at 0.1% relative error.')
