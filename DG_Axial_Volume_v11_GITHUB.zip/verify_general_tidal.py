"""Exact axial vacuum volume-jet reconstruction and static Zipoy--Voorhees control."""
import sympy as S
q,qd,qdd=symbols=S.symbols('q qd qdd',positive=True)
C4=-q*q/2;C5=-3*q*qd/10;C6=2*q**3/15-q*qdd/15-qd**2/20
assert S.factor(-10*C5/(3*q)-qd)==0
assert S.factor(2*q*q-3*qd*qd/(4*q)-15*C6/q-qdd)==0
# Reconstruct q from C4 with q>0; qdot sign is set by C5.
# Dimensionless residual D=(1+rho^2 rho'')/5 with rho=q^(-1/3).
rho=q**(-S.Rational(1,3));rhodd=S.diff(rho,q,2)*qd**2+S.diff(rho,q)*qdd
D=C6/q**3+S.Rational(1,15)+125*C5*C5/(81*q**5)
assert S.factor(D-(1+rho**2*rhodd)/5)==0
# Generic 2D static axial line element -f dt^2 + du^2/f: q=-f''/4.
# For ZV f=((u-k)/(u+k))^delta, u/k=t, f_u/f=A/k.
t,d,s=S.symbols('t d s',positive=True)
A=2*d/(t*t-1);R=d*(t-d)/(t*t-1)**2
B=A+1/(t-d)-4*t/(t*t-1) # (k/q)dq/du
# f''/f=(A'+A^2)/k^2 => q=f R/k^2
assert S.factor(-(S.diff(A,t)+A*A)/4-R)==0
D0=S.factor(S.Rational(1,5)+B*A/(30*R))
D1=S.factor((B*B/45-S.diff(B,t)/15)/R)
assert S.factor(D0-(d*d-1)/(15*(t-d)**2))==0
assert S.factor(D1-4*(d*d-1)*(d*d-3*d*t+3*t*t-1)/(45*d*(t-d)**3))==0
print('ZV rest residual:',D0,'speed slope:',D1)
for delta in [S.Rational(1,2),1,2]:
 print('delta=',delta,'t=4', 'D(s)=',S.factor((D0+s*D1).subs({d:delta,t:4})))
# Compare exact rest coefficient with a Schwarzschild cloud at same q, C4,C5.
u,k=S.symbols('u k',positive=True);f=((u-k)/(u+k))**2;Q=-S.diff(f,u,2)/4
at={u:4,k:1};q0=S.factor(Q.subs(at));qdd0=S.factor((-S.diff(Q,u)*S.diff(f,u)/2).subs(at))
C6z=S.factor(2*q0**3/15-q0*qdd0/15);C6s=-q0**3/15
assert S.factor((C6z-C6s)/q0**3)==S.Rational(1,20)
print('Matched static ZV/Schwarzschild q=',q0,'C4=',-q0*q0/2,'C5=0; normalized sixth-order difference=',S.factor((C6z-C6s)/q0**3))
# General local proper-distance jet (v is signed dr/dtau sqrt(s)/sqrt(f)).
f0,fp,Qr,Qrr=S.symbols('f0 fp Qr Qrr',real=True);b0=-fp*Qr/2;bs=s*f0*Qrr-fp*Qr/2
assert S.factor((bs-b0)/s-b0-(f0*Qrr+fp*Qr/2))==0
print('PASS: inverse volume jet, residual identity, static nonspherical counterexample, sign examples, local two-speed jet.')
# Inverse within the Kerr family returns a spurious spin if only two residuals are used.
# Exact ZV delta=2,t=4: D(0)=1/20, slope=9/20. Solve corresponding Kerr equations.
z=S.symbols('z');pol=S.Poly(4*z*(1+z)**2-(1-3*z)**2,z);assert pol.count_roots(0,S.Rational(1,3))==1
zz=S.CRootOf(pol,0);K=4*z*(1+z)**3/(5*(1-3*z)**3);xx=(1+zz)/(2+S.Rational(9,20)/K.subs(z,zz));chi=S.sqrt(zz)/xx
# root isolation and conservative rational bounds certify physical range.
l,h=S.Rational(1006048,10**7),S.Rational(1006049,10**7);assert pol.count_roots(l,h)==1
# (1+z) and K(z) increase, so x(z) likewise increases. Bounds from endpoints.
xlo=(1+l)/(2+S.Rational(9,20)/K.subs(z,l));xhi=(1+h)/(2+S.Rational(9,20)/K.subs(z,h));assert xlo*xlo>h and 2*xhi<1+l
Lk=(1-6*zz+zz*zz)**2*((1+zz)/xx-2)/(1-3*zz)**3
Lz=S.factor((f*S.diff(Q,u)**2/(9*Q**3)).subs(at))
print('Static nonspherical ZV with same residuals as Kerr: z=',S.N(zz,16),'x=',S.N(xx,16),'apparent spin=',S.N(chi,16))
print('Additional speed-normalized qdot^2/(9 s q^3): ZV',Lz,'Kerr',S.N(Lk,16))
assert Lz==S.Rational(9,16)
# Kerr L reduces to (9/20) times rational ratio of z; bound via positive P on interval.
plo=1-6*h+l*l;phi=1-6*l+h*h
assert plo>0
Llo=S.Rational(9,16)*plo**2/(h*(1+h)**3)
assert Llo>Lz
print('PASS: exact Kerr residual match, physical Kerr domain, unequal additional invariant.')
