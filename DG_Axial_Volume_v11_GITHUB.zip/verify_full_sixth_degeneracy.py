"""Exact static ZV / extremal Kerr full six-jet degeneracy and seventh-order separation."""
import sympy as S
r,s,T=S.symbols('r s T',positive=True)
z=3-2*S.sqrt(2);x=S.sqrt(2)-1
FK=z*(1+z)**2/(5*(1-3*z)**2);HK=4*z*(1+z)**3/(5*(1-3*z)**3)*((1+z)/x-2)
assert S.simplify(FK-S.Rational(1,5))==0 and S.simplify(HK-S.Rational(8,5))==0
# Static ZV delta=2,k=1,u=3, q>0.
fZ=((r-1)/(r+1))**2;qZ=-S.diff(fZ,r,2)/4;Q=qZ.subs(r,3)
assert Q==S.Rational(1,128) and S.diff(qZ,r).subs(r,3)==0
# Kerr extremal with coordinate r_K selected to match calibrated q. Use dimensionless r=1 for normalized coefficients.
fK=1-2*x*r/(r*r+z);qK=x*r*(r*r-3*z)/(r*r+z)**3
assert S.simplify(S.diff(qK,r).subs(r,1))==0
rK=S.sqrt(S.simplify(qK.subs(r,1)/Q));mK=x*rK;aK=mK
assert S.simplify(rK>mK)==S.true
# Derive C7 independently from length recurrence.
q0,q1,q2,q3,q4,q5=S.symbols('q0:6');qs=[q0,q1,q2/2,q3/6,q4/24,q5/120]
def ln_length(k):
 a=[S.Integer(1),S.Integer(0)]
 for n in range(6):a.append(S.expand(k*sum(qs[j]*a[n-j] for j in range(n+1))/((n+1)*(n+2))))
 u=sum(a[i]*T**i for i in range(2,8));return S.Poly(S.expand(u-u*u/2+u**3/3),T)
logV=ln_length(2)+2*ln_length(-1)
assert S.factor(logV.nth(7)-(10*q0*q0*q1-q0*q3-2*q1*q2)/84)==0
# q' =0 and matched D for all speeds => matched C4,C5,C6. Check residual directly and calculate normalized C7 for inward motion.
def data(f,q,point):
 fv=S.factor(f.subs(r,point));fp=S.factor(S.diff(f,r).subs(r,point));qv=S.factor(q.subs(r,point));qrr=S.factor(S.diff(q,r,2).subs(r,point));qrrr=S.factor(S.diff(q,r,3).subs(r,point))
 D=S.simplify(S.Rational(1,5)-s*fv*qrr/(15*qv**2));C7=S.simplify(-qv*(-S.sqrt(s*fv)*(-3*fp*qrr/2+s*fv*qrrr))/84/qv**S.Rational(7,2));return D,C7
DZ,CZ=data(fZ,qZ,3);DK,CK=data(fK,qK,1)
assert S.simplify(DZ-S.Rational(1,5)-8*s/5)==0 and S.simplify(DK-DZ)==0
# square ratio removes radical ambiguity; positive values for all s>0.
ratio2=S.simplify(CK**2/CZ**2);assert S.simplify(ratio2-((3-2*S.sqrt(2))/(2*(10-7*S.sqrt(2)))))==0
assert S.simplify(ratio2<1)==S.true
print('Q:',Q,'Kerr r,m,a',S.N(rK,15),S.N(mK,15),S.N(aK,15))
print('Equal D(s):',DZ,'C4',-Q**2/2,'C5=0','C6/Q^3=',S.simplify(DZ-S.Rational(1,15)))
print('C7/Q^(7/2) ZV:',CZ,'Kerr:',CK)
print('Squared ratio Kerr/ZV:',ratio2,'s=1 values',S.N(CZ.subs(s,1),15),S.N(CK.subs(s,1),15))
print('PASS: all C0..C6 equal for any s and same direction, C7 separates for any nonzero speed.')
# Rest launches: q'=q''=q'''=0 and odd coefficients vanish. Check C8 from length series.
q4=S.symbols('q4');dataq=[q0,0,0,0,q4/24,0,0]
def restlog(k):
 a=[S.Integer(1),S.Integer(0)]
 for n in range(7):a.append(S.expand(k*sum(dataq[j]*a[n-j] for j in range(n+1))/((n+1)*(n+2))))
 u=sum(a[i]*T**i for i in range(2,9));return S.Poly(S.expand(u-u*u/2+u**3/3-u**4/4),T)
c8=(restlog(2)+2*restlog(-1)).nth(8);assert S.factor(c8+17*q0**4/140+q0*q4/560)==0
# actual scaled Kerr parameters
fKphys=1-2*mK*r/(r*r+aK*aK);qKphys=mK*r*(r*r-3*aK*aK)/(r*r+aK*aK)**3
for ff,qq,rr in [(fZ,qZ,3),(fKphys,qKphys,4)]:
 for v,target in [(qq.subs(r,rr),Q),(S.diff(qq,r).subs(r,rr),0),(S.diff(ff,r).subs(r,rr),S.Rational(1,8)),((ff*S.diff(qq,r,2)).subs(r,rr),-S.Rational(3,2048)),((ff**2*S.diff(qq,r,3)).subs(r,rr),S.Rational(15,16384))]:
  assert S.simplify(v-target)==0
print('PASS: common calibrated spatial derivative combinations.')
def rest8(f,q,p):
 q4=S.simplify(3*S.diff(q,r,2).subs(r,p)*S.diff(f,r).subs(r,p)**2/4)
 return S.simplify(c8.subs({q0:Q,S.Symbol('q4'):q4})/Q**4)
RZ,RK=rest8(fZ,qZ,3),rest8(fKphys,qKphys,4)
assert S.simplify(RZ-S.Rational(19,140))==0
assert S.simplify(RK-(1+9*S.sqrt(2))/140)==0
print('Rest eighth coefficients C8/Q^4: ZV',RZ,'Kerr',RK)
print('PASS: rest records first separate at eighth order.')
# General stationary-gradient identities in an arbitrary smooth static-axis lapse.
f,fp,fpp,u2,u3,A,ell2,ell3,eps=S.symbols('f fp fpp u2 u3 A ell2 ell3 eps',real=True)
# f>0, q_u=0. q_ell,ell=f*q_uu, q_ell,ell,ell=f^(3/2)*q_uuu+3*sqrt(f)*f_u*q_uu/2.
A0=fp/(2*S.sqrt(f));E2=f*u2;E3=f**S.Rational(3,2)*u3+S.Rational(3,2)*S.sqrt(f)*fp*u2
qt3=eps*S.sqrt(s*f)*(s*f*u3-S.Rational(3,2)*fp*u2)
assert S.simplify(qt3-eps*S.sqrt(s)*(s*E3-3*(1+s)*A0*E2))==0
assert S.simplify(3*u2*fp**2/4-3*A0**2*E2)==0
W=s*ell3-3*(1+s)*A*ell2
s1,s2=S.symbols('s1 s2',positive=True);intercept=S.factor((s2*W.subs(s,s1)-s1*W.subs(s,s2))/(s2-s1));assert intercept==-3*A*ell2
# A static metric has vanishing Weyl Pontryagin. For the matched Kerr point the phase is 6*pi/8.
assert S.simplify(S.im((1+S.I*(S.sqrt(2)-1))**(-6)))!=0
print('PASS: general stationary-gradient seventh/eighth identities and local Kerr pseudoscalar nonzero.')
