"""Radial Schwarzschild cloud protocol in m=c=1 units.

Compare a finite-difference estimator from direct ODE integration with
the exact sixth-order coefficients. Here h is c*tau/m. The conditional
remainder bound is derived in the paper; this numerical convergence
test is not an interval certificate for that bound.
"""
import numpy as np
import mpmath as mp
from scipy.integrate import solve_ivp

def coefficients(r, s):
    k = 1 / r**3
    return -k**3 / 15 - 1.25 * k**2 * (1 - 2 / r) * s / r**2

def exact_scalar(r):
    return (45*r - 98) / (480*r**9)

def trajectory(r, s, sign, times, tolerance):
    radial_velocity = sign * np.sqrt((1 - 2/r)*s)
    def rhs(t, y):
        radius, speed, x, dx, z, dz = y
        k = radius**-3
        return [speed, -radius**-2, dx, 2*k*x, dz, -k*z]
    sol = solve_ivp(rhs, (0, max(times)), [r, radial_velocity, 1, 0, 1, 0],
                    method="DOP853", t_eval=times, rtol=tolerance, atol=tolerance/100)
    assert sol.success and np.all(sol.y[0] > 2) and np.all(sol.y[2] > 0) and np.all(sol.y[4] > 0)
    values = np.log(sol.y[2]) + 2*np.log(sol.y[4])
    return values

def estimate(r, s, h, tolerance):
    times = [h, 2*h]
    even = (trajectory(r, s, 1, times, tolerance)
            + trajectory(r, s, -1, times, tolerance))/2
    return (even[1] - 16*even[0])/(48*h**6)

def convolution(a, b, degree):
    return sum(a[j]*b[degree-j] for j in range(degree+1))

def taylor_volume(r, s, sign, h, order):
    """Independent high-precision Taylor recurrence for radial and Jacobi ODEs."""
    radius = [mp.mpf(r), sign*mp.sqrt((1-2/mp.mpf(r))*s)]
    inv = []
    inv2 = []
    inv3 = []
    x = [mp.mpf(1), mp.mpf(0)]
    z = [mp.mpf(1), mp.mpf(0)]
    for n in range(order-1):
        inv.append(1/radius[0] if n==0 else
                   -sum(radius[j]*inv[n-j] for j in range(1,n+1))/radius[0])
        inv2.append(convolution(inv, inv, n))
        inv3.append(convolution(inv2, inv, n))
        fac = (n+1)*(n+2)
        radius.append(-inv2[n]/fac)
        x.append(2*convolution(inv3, x, n)/fac)
        z.append(-convolution(inv3, z, n)/fac)
    def ev(a):
        return mp.polyval(list(reversed(a)), h)
    assert ev(radius)>2 and ev(x)>0 and ev(z)>0
    return mp.log(ev(x))+2*mp.log(ev(z))

def taylor_estimate(r, s, h, order):
    def even(t):
        return (taylor_volume(r,s,1,t,order)+taylor_volume(r,s,-1,t,order))/2
    return (even(2*h)-16*even(h))/(48*h**6)

def high_precision_check():
    mp.mp.dps=65
    print("High-precision Taylor comparison, 40 versus 60 terms")
    h=mp.mpf("0.1")
    for r in (mp.mpf("2.1"), mp.mpf(98)/45, mp.mpf("2.25")):
        frozen=1/(30*r**9)
        def project(n):
            return (13*taylor_estimate(r,0,h,n)-3*taylor_estimate(r,1,h,n))/40
        a,b=project(40),project(60)
        assert abs(a-b)/frozen < mp.mpf("1e-29")
        ratio=b/frozen
        err_limit=abs(b)*48*h**6/(mp.mpf("0.4")*17)
        print("r/rs=",mp.nstr(r/2,10),"normalized finite =",mp.nstr(ratio,12),
              "finite sign noise limit =",mp.nstr(err_limit,6),
              "order difference =",mp.nstr(abs(a-b)/frozen,4))

def main():
    print("r/(2m) h*c/m exact normalized scalar estimated normalized scalar")
    for r in (2.1, 98/45, 2.25):
        frozen=1/(30*r**9)
        assert abs((13*coefficients(r, 0)-3*coefficients(r, 1))/40-exact_scalar(r))<1e-18
        for h in (.1,.075,.05):
            def scalar_est(tol):
                return (13*estimate(r,0,h,tol)-3*estimate(r,1,h,tol))/40/frozen
            est=scalar_est(2.5e-14)
            coarse=scalar_est(2.5e-13)
            print(f"{r/2:.9f} {h:.3f} {exact_scalar(r)/frozen:+.9f} {est:+.9f} (tolerance change {abs(est-coarse):.2e})")
        if r != 98/45:
            h=.075
            assert np.sign(scalar_est(2.5e-14))==np.sign(exact_scalar(r))
    high_precision_check()
    print("PASS: exact radial identity, finite-window sign check and tolerance comparison.")
if __name__=="__main__":
    main()
