"""Exact unprojected sixth coefficient in the static equatorial tetrad (c=1)."""
import sympy as sp
from itertools import product
from verify_schwarzschild_sixth import all_lower_riemann, covariant_derivative, tidal_polynomial, radius as r, mass as m

def product_trace(*factors):
    out={}
    for terms in product(*(f.items() for f in factors)):
        idx=tuple(sorted(i for slots,_ in terms for i in slots))
        if 3 in idx:continue
        M=terms[0][1]
        for _,N in terms[1:]:M=M*N
        v=M.trace()
        if v:out[idx]=out.get(idx,0)+v
    t,b,d=sp.symbols('T B D',nonnegative=True)
    v=0;f=1-2*m/r
    for slots,value in out.items():
        value=sp.factor(value)
        if not value:continue
        counts=[slots.count(i) for i in range(3)]
        assert all(n%2==0 for n in counts),(slots,value)
        i,j,k=[n//2 for n in counts]
        v+=value*(t/f)**i*(b*f)**j*(d/r**2)**k
    return sp.factor(v)
def main():
    R=all_lower_riemann();R1=covariant_derivative(R);R2=covariant_derivative(R1)
    J,J1,J2=map(tidal_polynomial,(R,R1,R2))
    terms=[product_trace(J,J,J),product_trace(J,J2),product_trace(J1,J1)]
    for name,val in zip(['trace J0^3','trace J0 J2','trace J1^2'],terms):print(name,'=',val)
    combined=sp.factor(-terms[0]/45-terms[1]/90-terms[2]/120)
    print('C6=',combined)
    T,B,D=sp.symbols('T B D',nonnegative=True)
    p02=(r-2*m)*B*(30*D**2+20*D+4)+5*(3*m-r)*D**3+(19*m-5*r)*D**2+(9*m-2*r)*D+m
    p11=B*(25*D**2+16*D+3)+D**2+D
    expected=[-3*m**3*(1+3*D)*(2+3*D)/r**9,18*m**2*p02/r**9,18*m**2*(r-2*m)*p11/r**9]
    for actual,target in zip(terms,expected):
        assert sp.factor(actual.subs(T,1+B+D)-target)==0
    print('PASS: all three individual shell trace polynomials.')
    unit=sp.factor(combined.subs(T,1+B+D))
    print('unit shell=',unit)
    P=(r-2*m)*B*(585*D**2+384*D+75)+60*(3*m-r)*D**3+(174*m-51*r)*D**2+(54*m-15*r)*D+4*m
    assert sp.factor(unit+m**2*P/(60*r**9))==0
    # Use the rank-dependent pairing coefficient 1/(2^n (n+1)!).
    def moment(j,k):
        n=j+k
        return (-1)**n*sp.factorial2(2*j-1)*2**k*sp.factorial(k)/(2**n*sp.factorial(n+1))
    projected=sp.factor(sum(v*moment(j,k) for (j,k),v in sp.Poly(unit,B,D).terms()))
    assert projected==m**2*(-98*m+45*r)/(480*r**9)
    print('Direct shell polynomial projection:',projected)
    assert sp.factor(unit.subs(D,0)-(-m**3/(15*r**9)-5*m**2*(r-2*m)*B/(4*r**9)))==0
    print('PASS: direct shell formula, scalar and radial restriction.')
if __name__=='__main__':main()
