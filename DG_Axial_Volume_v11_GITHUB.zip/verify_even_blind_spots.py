"""Axial Kerr: degeneracy of even volume coefficients through sixth order."""
import sympy as S
z,x,s=S.symbols('z x s',positive=True)
P=1-6*z+z*z
F=z*(1+z)**2/(5*(1-3*z)**2)
K=4*z*(1+z)**3/(5*(1-3*z)**3)
L=P**2/(1-3*z)**3*((1+z)/x-2)
H=K*((1+z)/x-2)
# qdot^2/q^3=9sL. C6/q^3 = F-1/15+s(H-5L/4)
B=S.factor(H-S.Rational(5,4)*L)
Q=16*z*(1+z)**3-25*P**2
assert S.factor(B-((1+z)/x-2)*Q/(20*(1-3*z)**3))==0
# Verify L directly from radial derivative of q in Kerr coordinates.
r,m,a=S.symbols('r m a',positive=True)
q=m*r*(r*r-3*a*a)/(r*r+a*a)**3;f=1-2*m*r/(r*r+a*a)
assert S.simplify((f*S.diff(q,r)**2/(9*q**3)).subs({m:x*r,a:S.sqrt(z)*r})-L)==0
# Self-contained Descartes proof identity and converse away from P=0.
t=S.symbols('t',positive=True)
assert S.factor(9*(1+t)**4*Q.subs(z,t/(3*(1+t)))-(-64*t**4+256*t**3+592*t**2+48*t-225))==0
assert Q.subs(z,0)==-25 and Q.subs(z,S.Rational(1,6))==S.Rational(607,144) and Q.subs(z,S.Rational(1,3))==-S.Rational(64,9)
assert S.factor((1+z)/(2+20*(1-3*z)**3*B/Q)-x)==0
print('PASS self-contained root polynomial and even inverse outside roots.')
# Exact rational root isolation for the quartic in the admissible interval.
poly=S.Poly(Q,z); intervals=poly.intervals(eps=S.Rational(1,10**18)); print('All real root intervals:',intervals)
assert poly.count_roots(0,S.Rational(1,3))==2
for i in range(2):
 zz=S.CRootOf(poly,i)
 assert S.N(zz,40)>0 and S.N(zz,40)<S.Rational(1,3)
 assert abs(S.N(Q.subs(z,zz),40))<S.Float('1e-35')
 # x must satisfy |a|<=m and exterior r>r_plus. Choose 2 distinct interior x.
 lo=S.sqrt(zz);hi=(1+zz)/2
 assert S.N(hi-lo,40)>0
 print('blind z=',S.N(zz,16),'|a|/r=',S.N(S.sqrt(zz),16),'C6/q^3=',S.N(F.subs(z,zz)-S.Rational(1,15),16))
 for frac in [S.Rational(1,3),S.Rational(2,3)]:
  xx=lo+frac*(hi-lo)
  # choose common calibrated q=1; determine r,m,a.
  rr=S.sqrt(xx*(1-3*zz)/(1+zz)**3); mm=xx*rr; aa=S.sqrt(zz)*rr
  print('  x=',S.N(xx,12),'spin=',S.N(aa/mm,12),'r=',S.N(rr,12),'m=',S.N(mm,12),'a=',S.N(aa,12),'C5^2/q^5 at s=1=',S.N(S.Rational(81,100)*L.subs({z:zz,x:xx}),12))
print('PASS exact slope factorization, quartic, and physical degeneracy examples.')
