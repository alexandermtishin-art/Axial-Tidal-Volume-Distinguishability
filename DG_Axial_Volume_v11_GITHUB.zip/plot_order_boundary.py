"""Exact order-separation coefficients for matched static ZV and extremal Kerr."""
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
s=np.linspace(0,2,400);a=2*np.sqrt(2*s)*(10*s+3)/7;b=a*np.sqrt(.5+np.sqrt(2)/4)
fig,ax=plt.subplots(1,2,figsize=(7.1,3.4),gridspec_kw={'width_ratios':[1.65,1]})
ax[0].plot(s,a,label='Static ZV',color='#9c342e',lw=2);ax[0].plot(s,b,label='Extremal Kerr',color='#284e70',lw=2,ls='--');ax[0].set_xlabel(r'Squared spatial four-velocity $s$');ax[0].set_ylabel(r'$C_7/Q^{7/2}$ (inward)');ax[0].legend(frameon=False,fontsize=9);ax[0].grid(alpha=.2);ax[0].set_title('(a) Moving launch',fontsize=11)
V=[19/140,(1+9*np.sqrt(2))/140];ax[1].bar(['ZV','Kerr'],V,color=['#9c342e','#284e70'],width=.56);ax[1].set_ylabel(r'$C_8/Q^4$');ax[1].set_ylim(0,.16);ax[1].set_title('(b) Rest launch',fontsize=11)
for i,v in enumerate(V):ax[1].text(i,v+.004,f'{v:.5f}',ha='center',fontsize=9)
fig.tight_layout();fig.savefig(Path(__file__).with_name('figure_order.png'),dpi=300);plt.close(fig)
