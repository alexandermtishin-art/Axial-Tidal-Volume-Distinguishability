"""Geometrized units: exact axial Kerr versus matched Schwarzschild volume jets.
The numerical stage integrates Jacobi lengths and estimates coefficients from separate
sets of volume records, without imposing their analytic relation on the fits.
"""
import sympy as S
import mpmath as mp
r,m,a,b=S.symbols('r m a b',positive=True)
f=1-2*m*r/(r*r+a*a); q=m*r*(r*r-3*a*a)/(r*r+a*a)**3
qr=S.diff(q,r); qrr=S.diff(qr,r)
D=S.factor(q**3/5+q*qr*S.diff(f,r)/30+b*f*(-q*qrr/15+4*qr**2/45))
expected=a*a*m**3*r*(r*r-3*a*a)/(5*(r*r+a*a)**7)+4*a*a*m*m*b*(r*r-2*m*r+a*a)/(5*(r*r+a*a)**6)
assert S.factor(D-expected)==0
assert S.factor(D.subs(a,0))==0
# Coefficients independently derived via scalar Jacobi recurrence, formal q(t) jet.
t=S.symbols('t'); Q,Q1,Q2,Q3,Q4=S.symbols('Q Q1 Q2 Q3 Q4'); jet=[Q,Q1,Q2/2,Q3/6,Q4/24]
def log_length(k):
    # y''=k q(t)y, y(0)=1,y'(0)=0
    coeff=[S.Integer(1),S.Integer(0)]
    for n in range(5): coeff.append(S.expand(k*sum(jet[j]*coeff[n-j] for j in range(n+1))/((n+1)*(n+2))))
    u=sum(coeff[n]*t**n for n in range(2,7))
    return S.Poly(S.expand(u-u*u/2+u**3/3),t)
L=log_length(2)+2*log_length(-1)
assert S.factor(L.nth(4)+Q**2/2)==0
assert S.factor(L.nth(5)+3*Q*Q1/10)==0
assert S.factor(L.nth(6)-(2*Q**3/15-Q*Q2/15-Q1**2/20))==0
p={m:1,a:S.Rational(1,2),r:3,b:1}
q0=q.subs(p); v=-S.sqrt((b*f).subs(p)); dq=qr.subs(p)*v
R=S.factor(2+dq**2/(9*q0**3)); rs=S.sqrt(1/(q0*R)); ms=rs/R
# Same b, positive q and qdot, and thus identical C4 and C5.
assert S.simplify(ms/rs**3-q0)==0
assert S.simplify(3*q0/rs*S.sqrt(1-2/R)-dq)==0
print('Kerr exact residual:',S.factor(D))
print('Matched Schwarzschild r/m, m, r:',R,S.N(ms,14),S.N(rs,14))
print('Kerr normalized residual:',S.factor((D/q**3).subs(p)),S.N((D/q**3).subs(p),15))
print('Static example normalized residual:',S.factor((D/q**3).subs({**p,b:0})))
mp.mp.dps=55
num=lambda z:mp.mpf(str(S.N(z,57)))
# Direct integration of geodesic and two initially comoving Jacobi lengths.
def record(M,A,r0):
    def f(x):return 1-2*M*x/(x*x+A*A)
    def ode(t,z):
        x,v,y,Y,w,W=z
        q=M*x*(x*x-3*A*A)/(x*x+A*A)**3
        return [v,-M*(x*x-A*A)/(x*x+A*A)**2,Y,2*q*y,W,-q*w]
    sol=mp.odefun(ode,0,[r0,-mp.sqrt(f(r0)),1,0,1,0],tol=mp.mpf('1e-48'),degree=30)
    def fit(h,offset):
        # 12 independent nonzero positive samples, disjoint offsets for low / high fits.
        u=[(mp.mpf(n)+offset)/12 for n in range(1,13)]
        vol=[]
        for x in u:
            z=sol(h*x); vol.append(mp.log(z[2])+2*mp.log(z[4]))
        # fit orders 4...15 without imposing relationships among coefficients
        X=mp.matrix([[x**k for k in range(4,16)] for x in u]); cc=mp.lu_solve(X,mp.matrix(vol))
        return [cc[k-4]/h**k for k in (4,5,6)]
    for h in (mp.mpf('.08'),mp.mpf('.04')):
        low=fit(h,mp.mpf('0')); high=fit(h,mp.mpf('.5'))
        qe=mp.sqrt(-2*low[0]); residual=high[2]+qe**3/15+125*low[1]**2/(81*qe**2)
        print('h=',h,'C4=',mp.nstr(low[0],14),'C5=',mp.nstr(low[1],14),'C6=',mp.nstr(high[2],14),'D/q^3=',mp.nstr(residual/qe**3,14))
        target=num((D/q**3).subs(p)) if A else mp.mpf(0)
        assert abs(residual/qe**3-target)<mp.mpf('1e-6')
print('Kerr:');record(mp.mpf(1),mp.mpf('.5'),mp.mpf(3))
print('Schwarzschild:');record(num(ms),mp.mpf(0),num(rs))
print('PASS: exact and separate-record numerical checks.')
