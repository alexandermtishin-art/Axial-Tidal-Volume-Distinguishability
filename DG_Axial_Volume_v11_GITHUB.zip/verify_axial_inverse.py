"""Exact inverse of the two-launch axial Kerr volume residual (geometrized units)."""
import sympy as S
z,x,r,s=S.symbols('z x r s',positive=True)
q=x*(1-3*z)/(r*r*(1+z)**3)
F=z*(1+z)**2/(5*(1-3*z)**2)
K=4*z*(1+z)**3/(5*(1-3*z)**3)
H=K*((1+z)/x-2)
# H6 expression in v4 after m=x*r, a^2=z*r^2, divided by q^3
D0=z*r*r*(x*r)**3*r*(r*r-3*z*r*r)/(5*(r*r+z*r*r)**7)
D1=4*z*r*r*(x*r)**2*(r*r-2*x*r*r+z*r*r)/(5*(r*r+z*r*r)**6)
assert S.factor(D0/q**3-F)==0
assert S.factor(D1/q**3-H)==0
assert S.factor(S.diff(F,z)-(1+z)*(1+6*z-3*z*z)/(5*(1-3*z)**3))==0
assert S.factor((1+z)/(2+H/K)-x)==0
assert S.factor(x*(1-3*z)/(q*(1+z)**3)-r*r)==0
p={z:S.Rational(1,36),x:S.Rational(1,3),r:S.Integer(3)}
F0=F.subs(p);H0=H.subs(p);q0=q.subs(p)
assert F0+H0==S.Rational(39701,970299)
# polynomial equation for z from F0; unique root on (0,1/3) by monotonicity
roots=S.solve(z*(1+z)**2-5*F0*(1-3*z)**2,z)
assert S.Rational(1,36) in roots
z0=S.Rational(1,36);x0=S.simplify((1+z0)/(2+H0/K.subs(z,z0)));r0=S.sqrt(x0*(1-3*z0)/(q0*(1+z0)**3))
assert (x0,r0,x0*r0,S.sqrt(z0)*r0)==(S.Rational(1,3),3,1,S.Rational(1,2))
print('Rest residual:',F0,'speed slope:',H0,'moving residual:',F0+H0)
print('Recovered z, compactness m/r, radius, mass, |a|, |a|/m:',z0,x0,r0,x0*r0,S.sqrt(z0)*r0,S.sqrt(z0)/x0)
print('PASS: exact factorization, monotonicity derivative, inversion and example.')
