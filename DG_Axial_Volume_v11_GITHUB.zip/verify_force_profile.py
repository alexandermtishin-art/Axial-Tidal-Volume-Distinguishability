"""Exact force-gradient example, scalar recurrence and a counterexample to arbitrary-field inference."""
import sympy as S
x,y,z,l=S.symbols('x y z l',real=True);P=-(z*z-(x*x+y*y)/2)+l*(z**4-3*z*z*(x*x+y*y)+S.Rational(3,8)*(x*x+y*y)**2)
assert S.factor(sum(S.diff(P,v,2) for v in (x,y,z)))==0
q=1-6*l*z*z
assert S.hessian(P,(x,y,z)).subs({x:0,y:0})==S.diag(q,q,-2*q)
# Along central axis, z(0)=0, velocity=1, z''(0)=0.
q0=q.subs(z,0);q1=S.diff(q,z).subs(z,0);q2=S.diff(q,z,2).subs(z,0)
C4=-q0*q0/2;C5=-3*q0*q1/10;C6=2*q0**3/15-q0*q2/15-q1*q1/20
assert (C4,C5)==(-S.Rational(1,2),0)
assert S.factor(C6-2*S.Rational(1,15)-4*l/5)==0
for L in (0,S.Rational(1,12)):print('lambda',L,'C4,C5,C6',C4,C5,C6.subs(l,L))
# Independently expand y,w; q(τ)=1−6λτ²+O(τ^4) on this trajectory.
t=S.symbols('t');jet=[S.Integer(1),S.Integer(0),-6*l,S.Integer(0),S.symbols('Q4')]
def loglength(k):
 a=[S.Integer(1),S.Integer(0)]
 for n in range(5):a.append(S.expand(k*sum(jet[j]*a[n-j] for j in range(n+1))/((n+1)*(n+2))))
 u=sum(a[i]*t**i for i in range(2,7));return S.Poly(S.expand(u-u*u/2+u**3/3),t)
R=loglength(2)+2*loglength(-1)
assert S.factor(R.nth(4)-C4)==0 and S.factor(R.nth(5)-C5)==0 and S.factor(R.nth(6)-C6)==0
print('PASS: harmonic potential, force-gradient eigenvalues, independently expanded log volume. Uniform force has zero gradient and therefore is invisible in this measurement.')
