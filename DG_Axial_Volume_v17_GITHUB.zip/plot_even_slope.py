"""Plot polynomial controlling the even sixth-order speed slope in axial Kerr."""
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
u=np.linspace(0,1/np.sqrt(3),1000);z=u*u
P=lambda z:16*z*(1+z)**3-25*(1-6*z+z*z)**2
roots=np.roots([-9,348,-902,316,-25]);roots=sorted(np.sqrt(v.real) for v in roots if abs(v.imag)<1e-9 and 0<v.real<1/3)
fig,ax=plt.subplots(figsize=(6.4,3.6));ax.plot(u,P(z),color='#284e70',lw=2,label=r'$P((|a|/r)^2)$');ax.axhline(0,color='0.35',lw=.8);ax.scatter(roots,[0,0],color='#9c342e',zorder=3)
for v,offset in zip(roots,[(0,-23),(0,12)]):ax.annotate(f'{v:.6f}',(v,0),xytext=offset,textcoords='offset points',ha='center',fontsize=10)
ax.set_xlabel(r'Rotation length to radius, $|a|/r$');ax.set_ylabel(r'Slope polynomial $P(\alpha)$');ax.set_xlim(0,1/np.sqrt(3));ax.grid(alpha=.2);fig.tight_layout();fig.savefig(Path(__file__).with_name('figure2.png'),dpi=300);plt.close(fig)
