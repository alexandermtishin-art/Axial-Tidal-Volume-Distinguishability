"""Verify the directional and log-volume separation orders for the axial examples."""
from math import factorial

import sympy as sp


def length_coefficients(tidal_derivatives, multiplier, order):
    coefficients = [sp.S.One, sp.S.Zero]
    for n in range(order - 1):
        forcing = sum(
            tidal_derivatives[j] * coefficients[n-j] / factorial(j)
            for j in range(n+1)
        )
        coefficients.append(sp.expand(multiplier * forcing / ((n+1)*(n+2))))
    return coefficients


def logarithm_coefficients(length):
    # L (log L)' = L', with L(0) = 1.
    logarithm = [sp.S.Zero]
    for n, coefficient in enumerate(length[1:], start=1):
        product = sum(j * logarithm[j] * length[n-j] for j in range(1, n))
        logarithm.append(sp.expand(coefficient - product / n))
    return logarithm


def verify_order(k, expected_volume_factor):
    order = k + 4
    common = list(sp.symbols(f"q0:{k}"))
    first = common + list(sp.symbols(f"a{k}:{k+3}"))
    second = common + list(sp.symbols(f"b{k}:{k+3}"))
    tidal_difference = second[k] - first[k]
    log_differences = []

    for multiplier in (2, -1):
        lhs = length_coefficients(first, multiplier, order)
        rhs = length_coefficients(second, multiplier, order)
        assert rhs[:k+2] == lhs[:k+2]
        assert sp.expand(rhs[k+2] - lhs[k+2] - multiplier*tidal_difference/factorial(k+2)) == 0
        log_differences.append([
            sp.expand(b - a)
            for a, b in zip(logarithm_coefficients(lhs), logarithm_coefficients(rhs))
        ])

    volume_difference = [sp.expand(y + 2*w) for y, w in zip(*log_differences)]
    assert volume_difference[:order] == [0]*order
    assert sp.expand(volume_difference[order] - expected_volume_factor*common[0]*tidal_difference) == 0
    print(f"First unequal derivative {k}: axial/transverse length order {k+2}, log-volume order {order}")


if __name__ == "__main__":
    verify_order(3, -sp.Rational(1, 84))
    verify_order(4, -sp.Rational(1, 560))
