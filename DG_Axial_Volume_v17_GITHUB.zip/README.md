# Preparation-dependent loss of gravitational distinguishability in Jacobi volume records — v17

Repository: https://github.com/alexandermtishin-art/Axial-Tidal-Volume-Distinguishability

The manuscript uses initially co-moving Jacobi data in the Schwarzschild, axial Kerr and static nonspherical ZV exterior regions. All inputs are mathematical model parameters. No measured astronomical data are included.

Tested with Python 3.12.14, SymPy 1.14.0, NumPy 2.3.5, SciPy 1.17.0, mpmath 1.3.0 and Matplotlib 3.10.8. Install the listed packages in an isolated Python environment. No random seeds are needed.

## Quick check

Run from the extracted directory:

    python verify_radial_identity.py
    python verify_lower_order.py
    python verify_sixth_sampling.py
    python radial_window.py
    python plot_response.py
    python plot_even_slope.py
    python verify_kerr_discrimination.py
    python verify_kerr_intervals.py
    python verify_axial_inverse.py
    python verify_even_blind_spots.py
    python check_blind_spot_records.py
    python verify_general_tidal.py
    python check_static_volume.py
    python verify_force_profile.py
    python verify_full_sixth_degeneracy.py
    python check_seventh_records.py
    python plot_order_boundary.py
    python verify_stationary_limits.py
    python plot_blind_speed.py

The first two print exact symbolic results. The numerical run compares DOP853 integrations at two tolerances and independently evaluates a Taylor recurrence at 65 decimal digits. Reference outputs are included. Small changes in floating point integration may occur across platforms. The signs at 21/20 and 9/8 and the tabulated high-precision estimates should agree. The difference of truncated Taylor series is a convergence check, not a rigorous enclosure of the tails.

## Full curvature check

The full directional polynomial and Appendix A trace products are checked by:

    python verify_directional_polynomial.py


    python verify_schwarzschild_sixth.py

This builds the tensor and its covariant derivatives from the Schwarzschild metric using exact SymPy arithmetic. No precomputed curvature arrays are required. The expected output is in symbolic_results.txt. Depending on the machine this computation can take several tens of seconds or longer; the compact radial identity and sampling checks provide faster exact verification of the specified formulas.

## Result mapping

- Equation (A5), local scalar and crossing in Section 4 and Appendix C: verify_schwarzschild_sixth.py; the direct metric contraction checks the stated sixth-order scalar, and independently checks its invariant representation. The symbolic result gives (45*r-98*m)*m**2/(480*r**9) in c=1 units.
- Appendix B (seven launches): verify_sixth_sampling.py, all ten monomials and error norm 62.
- Appendix B.2 (two radial settings, curvature contractions, compactness, measurement norm): verify_radial_identity.py; expected rational expressions in radial_identity_expected.txt.
- Appendix B.2.1: verify_lower_order.py checks the fourth/fifth recurrence and the symbolic consistency residual.
- Appendix A.2–A.3: verify_directional_polynomial.py; directional_expected.txt contains all trace products, the unit shell polynomial and its exact moment.
- Appendix B.3 (conditional finite-window error): elementary triangle inequality in the manuscript; verify_radial_identity.py checks both numeric multipliers. An independent remainder bound and calibration error budget are required for observations.
- Table 2: radial_window.py, high-precision calculation at h=0.1 in m=c=1 units, for r=2.1, 98/45, 2.25. The finite sign noise limit assumes exact times, launch settings and model. The printed value for the finite estimator at the local zero is not a noise bound for identifying the local zero.
- Figure 3: plot_response.py. Exact normalized line (90*x-98)/16 for x=r/r_s, with markers 49/45 and 6/5. Output figure1.png.

The two radial settings are model-specific. Their error norm is not a replacement for the universal degree-six polynomial rule.

- Appendix D, Eqs. (D3)–(D4), Table 3: verify_kerr_discrimination.py checks the exact scalar Jacobi recurrence, Kerr residual, Schwarzschild matching, and separately sampled numerical volume fits for each model. Expected output: kerr_expected.txt. The numerical check is ideal, high precision, and may run for several seconds.
- Appendix D.3: verify_kerr_intervals.py uses exact rational/algebraic bounds for 0.1% relative coefficient uncertainty, checks the outward-rounded endpoints and their disjointness. Expected output: kerr_intervals_expected.txt.

- Appendix D.4, Eqs. (D7)–(D12): verify_axial_inverse.py checks exact factorization, monotonicity, the inverse and the rational example; axial_inverse_expected.txt.
- Appendix D.5, Eq. (D17): verify_even_blind_spots.py verifies the exact slope factorization, counts and isolates the two physical quartic roots using rational intervals, and prints two admissible examples at each root; even_blind_spots_expected.txt.
- Table 4: check_blind_spot_records.py integrates two Kerr geometries at two speeds and two windows with 60-digit precision, fits the log volumes without imposing the analytic identities and checks exterior trajectories; blind_spot_records_expected.txt. No empirical records or guaranteed experimental precision are claimed.

- Figure 4: plot_even_slope.py plots the quartic sign on the physical interval and labels its two roots; output figure2.png.

- Section 2.1: verify_general_tidal.py checks the inverse tidal jet, dimensionless residual and two-launch spatial derivative identities.
- Appendix D.6, Eq. (D23) and Table 5: verify_general_tidal.py checks exact ZV residuals, the physically admissible spurious Kerr inverse via rational root isolation, and the strict additional-invariant inequality. Expected: general_expected.txt. check_static_volume.py checks the static examples by direct 60-digit ODE integration and unconstrained log-volume fitting in two windows; static_volume_expected.txt.
- Discussion: verify_force_profile.py constructs the dimensionless harmonic electrostatic potentials and checks the exact sixth-order differences by independent length expansion; force_profile_expected.txt. The example is limited to the same force-gradient response, not arbitrary force fields.

- Section 2.2, Eqs. (10)–(15), Table 1: verify_full_sixth_degeneracy.py checks the exact all-speed equal sixth-order records, shared spatial derivative combinations, seventh-order formula and eighth-order rest formula and general stationary-gradient reconstruction identities. Expected: full_sixth_expected.txt. check_seventh_records.py integrates both models at 60 digits in two windows for s=0,1,2; fits powers 4–19 and checks C4–C7 plus rest C8. Expected: seventh_records_expected.txt. Each sampled node is in the regular exterior, not an interval proof of the whole trajectory. The exact theorem is independent of the numerical fit.
- Figure 1: plot_order_boundary.py builds the exact seventh-order curves and rest eighth-order bars; figure_order.png.

## Preparation-dependent loss and internal forces (v17)

- Section 2.3, Eqs. (17)–(18), Appendix E.1: verify_stationary_limits.py checks exact Weyl multipoles, arbitrary prescribed blind speed, two independent formal series calculations for s=0,1,2, and the leading relativistic balance. Expected: stationary_limits_expected.txt. No astronomical source or measurement feasibility is claimed.
- Section 3, Eq. (19), Appendix E.2: the same script checks restoring-force coefficients, transverse focusing threshold b=q and longitudinal marginality b=2q in the constant-tide model.
- Figure 2: run plot_blind_speed.py to generate figure_blind_speed.png. The reduced vertical scale in panel (a) is defined by its axis label.

Notation in the manuscript: sigma is the local axial coordinate, z is the Weyl axial coordinate, zeta is the polar cosine, and alpha = a^2/r^2 is the Kerr parameter. Some verification scripts retain z for their local Kerr parameter and b, w for the squared velocity components lambda, nu in Appendix A.

- Section 5, Eq. (21): run `python verify_directional_orders.py` to check the leading directional and log-volume orders for the two matched axial cases.
